sap.ui.define([
    "sap/ui/core/mvc/ControllerExtension",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/VBox",
    "sap/m/HBox",
    "sap/m/Label",
    "sap/m/TextArea",
    "sap/m/Input",
    "sap/m/Select",
    "sap/m/ComboBox",
    "sap/m/MultiComboBox",
    "sap/m/Text",
    "sap/m/Title",
    "sap/m/Toolbar",
    "sap/m/ToolbarSpacer",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/Item",
    "sap/ui/unified/FileUploader",
    "sap/ui/model/json/JSONModel"
], function (
    ControllerExtension,
    Dialog, Button, VBox, HBox, Label, TextArea, Input, Select,
    ComboBox, MultiComboBox, Text, Title, Toolbar, ToolbarSpacer,
    MessageToast, MessageBox, Item, FileUploader, JSONModel
) {
    "use strict";

    function getBaseUrl(sPath) {
        var sClean = sPath.startsWith("/") ? sPath.slice(1) : sPath;
        return "/" + sClean;
    }

    function applyClass(oControl, sClasses) {
        if (oControl && sClasses) {
            sClasses.split(" ").forEach(function (c) {
                if (c && c.trim()) {
                    oControl.addStyleClass(c.trim());
                }
            });
        }
        return oControl;
    }

    return ControllerExtension.extend("plm.translator.app.ext.customActions", {
        /**
         * @ui5ignore
         * @public
         * Quick Single Translation Action Dialog
         * Allows user to translate via Google Cloud, review/edit the output,
         * adjust accuracy rating, and save to Test Results.
         */
        onQuickTranslate: function (oEvent) {
            var oView = (this.base && this.base.getView) ? this.base.getView() : null;
            var oModel = new JSONModel({
                sourceText: "",
                targetLanguage: "de",
                translatedText: "",
                detectedLanguage: "auto",
                outcome: "Success",
                accuracy: 95,
                observation: "",
                testedBy: "Business User",
                isTranslating: false,
                isTranslated: false,
                languages: []
            });

            // 1. Load languages dynamically from Google Cloud Translation API
            fetch(getBaseUrl("api/getLanguages()"))
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    var aLangs = (data && data.value) ? data.value : (Array.isArray(data) ? data : []);
                    oModel.setProperty("/languages", aLangs);
                })
                .catch(function (e) {
                    console.warn("[QuickTranslate] Could not load languages dynamically:", e);
                });

            // 2. Fetch user info for testedBy default
            fetch(getBaseUrl("api/getUserInfo()"))
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    var u = (data && data.value) ? data.value : data;
                    if (u && u.user) {
                        oModel.setProperty("/testedBy", u.user);
                    }
                })
                .catch(function () {});

            var oDialog = new Dialog({
                title: "Single Translation",
                customHeader: new Toolbar({
                    content: [
                        applyClass(new Title({ text: "Single Translation", level: "H5" }), "sapUiSmallMarginBegin"),
                        new ToolbarSpacer(),
                        new Button({
                            icon: "sap-icon://decline",
                            type: "Transparent",
                            tooltip: "Close",
                            press: function () {
                                oDialog.close();
                            }
                        })
                    ]
                }),
                contentWidth: "760px",
                resizable: true,
                draggable: true,
                afterClose: function () {
                    oDialog.destroy();
                },
                content: [
                    new VBox({
                        width: "100%",
                        items: [
                            applyClass(new Label({ text: "Target Language:", required: true }), "sapUiTinyMarginBottom"),
                            new ComboBox({
                                width: "100%",
                                selectedKey: "{dialog>/targetLanguage}",
                                items: {
                                    path: "dialog>/languages",
                                    template: new Item({ key: "{dialog>code}", text: "{dialog>text}" })
                                }
                            }),

                            applyClass(new Label({ text: "Source Text to Translate:", required: true }), "sapUiSmallMarginTop sapUiTinyMarginBottom"),
                            new TextArea({
                                width: "100%",
                                rows: 3,
                                value: "{dialog>/sourceText}",
                                placeholder: "Enter source text to translate..."
                            }),

                            new HBox({
                                justifyContent: "End",
                                items: [
                                    applyClass(new Button({
                                        text: "Translate via Google Cloud",
                                        type: "Emphasized",
                                        icon: "sap-icon://translate",
                                        busy: "{dialog>/isTranslating}",
                                        press: function () {
                                            var sText = oModel.getProperty("/sourceText");
                                            var sLang = oModel.getProperty("/targetLanguage");
                                            if (!sText || !sText.trim()) {
                                                MessageToast.show("Please enter source text to translate.");
                                                return;
                                            }
                                            if (!sLang || !sLang.trim()) {
                                                MessageToast.show("Please select a target language.");
                                                return;
                                            }

                                            oModel.setProperty("/isTranslating", true);
                                            fetch(getBaseUrl("api/translate"), {
                                                method: "POST",
                                                headers: { "Content-Type": "application/json" },
                                                body: JSON.stringify({ text: sText.trim(), targetLanguage: sLang.trim() })
                                            })
                                            .then(function (res) { return res.json(); })
                                            .then(function (resData) {
                                                oModel.setProperty("/isTranslating", false);
                                                var res = (resData && resData.value) ? resData.value : resData;
                                                if (res && res.success) {
                                                    oModel.setProperty("/translatedText", res.translatedText);
                                                    oModel.setProperty("/detectedLanguage", res.sourceLanguage || "auto");
                                                    oModel.setProperty("/isTranslated", true);
                                                    if (!oModel.getProperty("/outcome")) {
                                                        oModel.setProperty("/outcome", "Success");
                                                    }
                                                    if (oModel.getProperty("/accuracy") === null || oModel.getProperty("/accuracy") === undefined || oModel.getProperty("/accuracy") === "") {
                                                        oModel.setProperty("/accuracy", 95);
                                                    }
                                                    MessageToast.show("Translation completed! You can now review and edit the output or adjust accuracy.");
                                                } else {
                                                    MessageBox.error((res && res.error) || "Translation failed");
                                                }
                                            })
                                            .catch(function (err) {
                                                oModel.setProperty("/isTranslating", false);
                                                MessageBox.error("Network error during translation: " + err.message);
                                            });
                                        }
                                    }), "sapUiTinyMarginTop")
                                ]
                            }),

                            applyClass(new Label({ text: "Translated Result:" }), "sapUiSmallMarginTop sapUiTinyMarginBottom"),
                            new TextArea({
                                width: "100%",
                                rows: 3,
                                editable: true,
                                value: "{dialog>/translatedText}",
                                placeholder: "Translated result will appear here. You can manually edit it after translation..."
                            }),

                            applyClass(new Title({ text: "Record Test Quality & Evaluation", level: "H5" }), "sapUiMediumMarginTop sapUiTinyMarginBottom"),
                            new HBox({
                                width: "100%",
                                justifyContent: "SpaceBetween",
                                items: [
                                    applyClass(new VBox({
                                        width: "48%",
                                        items: [
                                            applyClass(new Label({ text: "Outcome:" }), "sapUiTinyMarginBottom"),
                                            new Select({
                                                width: "100%",
                                                selectedKey: "{dialog>/outcome}",
                                                items: [
                                                    new Item({ key: "Success", text: "Success (Accurate)" }),
                                                    new Item({ key: "Partial", text: "Partial (Needs Edit)" }),
                                                    new Item({ key: "Failure", text: "Failure (Inaccurate)" })
                                                ]
                                            })
                                        ]
                                    }), "sapUiSmallMarginEnd"),
                                    new VBox({
                                        width: "48%",
                                        items: [
                                            applyClass(new Label({ text: "Accuracy Rating (0-100%):" }), "sapUiTinyMarginBottom"),
                                            new Input({
                                                width: "100%",
                                                type: "Number",
                                                value: "{dialog>/accuracy}",
                                                placeholder: "95"
                                            })
                                        ]
                                    })
                                ]
                            }),

                            applyClass(new Label({ text: "Evaluator / Tested By:" }), "sapUiSmallMarginTop sapUiTinyMarginBottom"),
                            new Input({
                                width: "100%",
                                value: "{dialog>/testedBy}",
                                placeholder: "Enter evaluator name"
                            }),

                            applyClass(new Label({ text: "Observations & Notes:" }), "sapUiSmallMarginTop sapUiTinyMarginBottom"),
                            new TextArea({
                                width: "100%",
                                rows: 2,
                                value: "{dialog>/observation}",
                                placeholder: "Optional evaluation notes..."
                            })
                        ]
                    })
                ],
                beginButton: new Button({
                    text: "Save to Test Results",
                    type: "Accept",
                    icon: "sap-icon://save",
                    press: function () {
                        var sSrc = oModel.getProperty("/sourceText");
                        var sTrans = oModel.getProperty("/translatedText");

                        if (!sSrc || !sSrc.trim()) {
                            MessageToast.show("Please enter source text and translate before saving.");
                            return;
                        }
                        if (!sTrans || !sTrans.trim()) {
                            MessageToast.show("Please perform translation or enter translated text before saving.");
                            return;
                        }

                        var accVal = oModel.getProperty("/accuracy");
                        var parsedAcc = (accVal !== null && accVal !== undefined && accVal !== "") ? parseFloat(accVal) : 95;
                        if (isNaN(parsedAcc) || parsedAcc < 0 || parsedAcc > 100) {
                            MessageToast.show("Accuracy rating must be between 0 and 100.");
                            return;
                        }

                        var sTargetLang = oModel.getProperty("/targetLanguage");
                        var aLangs = oModel.getProperty("/languages") || [];
                        var sLangText = sTargetLang;
                        for (var l = 0; l < aLangs.length; l++) {
                            if (aLangs[l].code === sTargetLang) {
                                sLangText = aLangs[l].text || aLangs[l].name || sTargetLang;
                                break;
                            }
                        }

                        oDialog.setBusy(true);
                        var payload = {
                            outcome: oModel.getProperty("/outcome") || "Success",
                            accuracy: parsedAcc,
                            observation: (oModel.getProperty("/observation") || "").trim(),
                            testedBy: (oModel.getProperty("/testedBy") || "Business User").trim(),
                            textToTranslate: sSrc.trim(),
                            translatedText: sTrans.trim(),
                            sourceLanguage: oModel.getProperty("/detectedLanguage") || "auto",
                            targetLanguage: sLangText
                        };

                        fetch(getBaseUrl("api/TestResults"), {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify(payload)
                        })
                        .then(function (res) {
                            if (!res.ok) {
                                return res.json().then(function (errData) {
                                    throw new Error((errData.error && errData.error.message) || res.statusText);
                                });
                            }
                            return res.json();
                        })
                        .then(function (saved) {
                            oDialog.setBusy(false);
                            oDialog.close();
                            MessageToast.show("Test evaluation logged successfully!");

                            // Refresh current FE view binding if available
                            if (oView && oView.getModel()) {
                                oView.getModel().refresh();
                            }
                            try {
                                var oTable = oView.byId("fe::table::TestResults::LineItem") || oView.byId("fe::table::TestResults::LineItem-innerTable");
                                if (oTable && oTable.getBinding && oTable.getBinding("items")) {
                                    oTable.getBinding("items").refresh();
                                } else if (oTable && oTable.getBinding && oTable.getBinding("rows")) {
                                    oTable.getBinding("rows").refresh();
                                }
                            } catch (refreshErr) {}
                        })
                        .catch(function (err) {
                            oDialog.setBusy(false);
                            MessageBox.error("Failed to save evaluation: " + err.message);
                        });
                    }
                }),
                endButton: new Button({
                    text: "Cancel",
                    press: function () {
                        oDialog.close();
                    }
                })
            });

            oDialog.addStyleClass("sapUiContentPadding sapUiResponsivePadding");
            oDialog.setModel(oModel, "dialog");
            oDialog.open();
        },

        /**
         * @ui5ignore
         * @public
         * Mass Translation Excel Upload Action Dialog
         */
        onMassUpload: function (oEvent) {
            var oView = (this.base && this.base.getView) ? this.base.getView() : null;
            var oModel = new JSONModel({
                testedBy: "Business User",
                targetLanguages: ["de", "fr", "es"],
                languages: [],
                statusText: ""
            });

            fetch(getBaseUrl("api/getLanguages()"))
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    var aLangs = (data && data.value) ? data.value : (Array.isArray(data) ? data : []);
                    oModel.setProperty("/languages", aLangs);
                })
                .catch(function () {});

            fetch(getBaseUrl("api/getUserInfo()"))
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    var u = (data && data.value) ? data.value : data;
                    if (u && u.user) {
                        oModel.setProperty("/testedBy", u.user);
                    }
                })
                .catch(function () {});

            var oUploader = new FileUploader({
                name: "file",
                uploadUrl: getBaseUrl("api/upload-and-translate"),
                fileType: ["xlsx", "xls"],
                mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel",
                placeholder: "Select an Excel spreadsheet (.xlsx, .xls)...",
                width: "100%"
            });

            var oMultiCombo = new MultiComboBox({
                width: "100%",
                selectedKeys: "{dialog>/targetLanguages}",
                items: {
                    path: "dialog>/languages",
                    template: new Item({ key: "{dialog>code}", text: "{dialog>text}" })
                },
                selectionChange: function (oEvent) {
                    var aSelected = oEvent.getSource().getSelectedKeys();
                    oModel.setProperty("/targetLanguages", aSelected);
                },
                selectionFinish: function (oEvent) {
                    var aSelected = oEvent.getSource().getSelectedKeys();
                    oModel.setProperty("/targetLanguages", aSelected);
                }
            });

            var oDialog = new Dialog({
                title: "Mass Translation",
                customHeader: new Toolbar({
                    content: [
                        applyClass(new Title({ text: "Mass Translation", level: "H5" }), "sapUiSmallMarginBegin"),
                        new ToolbarSpacer(),
                        new Button({
                            icon: "sap-icon://decline",
                            type: "Transparent",
                            tooltip: "Close",
                            press: function () {
                                oDialog.close();
                            }
                        })
                    ]
                }),
                contentWidth: "760px",
                resizable: true,
                draggable: true,
                afterClose: function () {
                    oDialog.destroy();
                },
                content: [
                    new VBox({
                        width: "100%",
                        items: [
                            new HBox({
                                width: "100%",
                                justifyContent: "SpaceBetween",
                                alignItems: "Center",
                                items: [
                                    new Label({ text: "Excel File:", required: true }),
                                    new Button({
                                        text: "Download Template (.xlsx)",
                                        icon: "sap-icon://download",
                                        type: "Transparent",
                                        press: function () {
                                            if (window.XLSX) {
                                                var wb = window.XLSX.utils.book_new();
                                                var wsData = [
                                                    ["Phrase Text", "Description"],
                                                    ["Welcome to our application", "Header greeting"],
                                                    ["Save Changes", "Button label"],
                                                    ["Error loading data", "Error alert"]
                                                ];
                                                var ws = window.XLSX.utils.aoa_to_sheet(wsData);
                                                ws["!cols"] = [{ wch: 35 }, { wch: 25 }];
                                                window.XLSX.utils.book_append_sheet(wb, ws, "Translations");
                                                window.XLSX.writeFile(wb, "mass_translation_template.xlsx");
                                                MessageToast.show("Template downloaded successfully.");
                                            } else {
                                                MessageBox.error("Excel export library is not loaded.");
                                            }
                                        }
                                    })
                                ]
                            }),
                            applyClass(oUploader, "sapUiTinyMarginTop"),

                            applyClass(new Label({ text: "Target Languages (Multi-Select):", required: true }), "sapUiSmallMarginTop sapUiTinyMarginBottom"),
                            oMultiCombo,

                            applyClass(new Label({ text: "Evaluator / Tested By:", required: true }), "sapUiSmallMarginTop sapUiTinyMarginBottom"),
                            new Input({
                                width: "100%",
                                value: "{dialog>/testedBy}",
                                placeholder: "Enter evaluator name"
                            }),

                            applyClass(new Text({
                                text: "{dialog>/statusText}"
                            }), "sapUiSmallMarginTop")
                        ]
                    })
                ],
                beginButton: new Button({
                    text: "Start Batch Translation",
                    type: "Emphasized",
                    icon: "sap-icon://upload",
                    press: function () {
                        var oDomRef = oUploader.getDomRef();
                        var oFileInput = oDomRef ? oDomRef.querySelector("input[type=file]") : null;
                        var oFile = oFileInput && oFileInput.files && oFileInput.files[0];

                        if (!oFile) {
                            MessageToast.show("Please select an Excel file to upload.");
                            return;
                        }

                        var aTargets = oMultiCombo.getSelectedKeys();
                        if (!aTargets || aTargets.length === 0) {
                            aTargets = oModel.getProperty("/targetLanguages");
                        }
                        if (!aTargets || aTargets.length === 0) {
                            MessageToast.show("Please select at least one target language.");
                            return;
                        }

                        var sTester = oModel.getProperty("/testedBy");
                        if (!sTester || !sTester.trim()) {
                            MessageToast.show("Please enter evaluator name.");
                            return;
                        }

                        if (!window.XLSX) {
                            MessageBox.error("Excel parser library is not loaded.");
                            return;
                        }

                        oDialog.setBusy(true);
                        oModel.setProperty("/statusText", "Reading and parsing Excel file in browser...");

                        var reader = new FileReader();
                        reader.onload = function (e) {
                            try {
                                var data = new Uint8Array(e.target.result);
                                var workbook = window.XLSX.read(data, { type: "array" });
                                var sheetName = workbook.SheetNames[0];
                                if (!sheetName) {
                                    oDialog.setBusy(false);
                                    MessageBox.error("Excel file has no sheets.");
                                    return;
                                }

                                var worksheet = workbook.Sheets[sheetName];
                                var rawData = window.XLSX.utils.sheet_to_json(worksheet, { defval: "" });
                                if (!rawData || rawData.length === 0) {
                                    oDialog.setBusy(false);
                                    MessageBox.error("Excel file is empty.");
                                    return;
                                }

                                var columns = Object.keys(rawData[0]);
                                var possibleTextColumns = [
                                    "Phrase Text", "phrase text", "PHRASE TEXT",
                                    "text", "Text", "TEXT",
                                    "content", "Content", "CONTENT",
                                    "message", "Message", "MESSAGE"
                                ];
                                var textCol = null;
                                for (var i = 0; i < possibleTextColumns.length; i++) {
                                    if (columns.indexOf(possibleTextColumns[i]) !== -1) {
                                        textCol = possibleTextColumns[i];
                                        break;
                                    }
                                }
                                if (!textCol) {
                                    textCol = columns[0];
                                }

                                var possibleDescColumns = ["description", "Description", "DESCRIPTION", "desc", "Desc", "notes", "Notes"];
                                var descCol = null;
                                for (var j = 0; j < possibleDescColumns.length; j++) {
                                    if (columns.indexOf(possibleDescColumns[j]) !== -1 && possibleDescColumns[j] !== textCol) {
                                        descCol = possibleDescColumns[j];
                                        break;
                                    }
                                }

                                var texts = [];
                                for (var k = 0; k < rawData.length; k++) {
                                    var row = rawData[k];
                                    var src = String(row[textCol] || "").trim();
                                    var desc = descCol && row[descCol] ? String(row[descCol]).trim() : "";
                                    if (["nan", "none", ""].indexOf(desc.toLowerCase()) !== -1) {
                                        desc = "";
                                    }
                                    if (src && ["nan", "none", ""].indexOf(src.toLowerCase()) === -1) {
                                        texts.push({
                                            index: k,
                                            text: src,
                                            description: desc
                                        });
                                    }
                                }

                                if (texts.length === 0) {
                                    oDialog.setBusy(false);
                                    MessageBox.error("No valid text rows found in Excel file.");
                                    return;
                                }

                                oModel.setProperty("/statusText", "Calling native CAP OData action: massTranslate (" + texts.length + " texts x " + aTargets.length + " languages)...");

                                fetch(getBaseUrl("api/massTranslate"), {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify({
                                        textsJson: JSON.stringify(texts),
                                        targetLanguages: JSON.stringify(aTargets),
                                        testedBy: sTester.trim()
                                    })
                                })
                                .then(function (res) { return res.json(); })
                                .then(function (resData) {
                                    oDialog.setBusy(false);
                                    var result = resData && resData.value ? resData.value : resData;
                                    if (result && result.success) {
                                        oDialog.close();
                                        MessageBox.success(
                                            "Mass Translation Completed!\n\n" +
                                            "Total Rows Processed: " + (result.statistics ? result.statistics.totalRows : "N/A") + "\n" +
                                            "Successful: " + (result.statistics ? result.statistics.successful : "N/A") + "\n" +
                                            "Success Rate: " + (result.statistics ? result.statistics.successRate + "%" : "N/A") + "\n" +
                                            "Session ID: " + (result.sessionId || "N/A"),
                                            {
                                                title: "Batch Translation Summary",
                                                onClose: function () {
                                                    if (oView && oView.getModel()) {
                                                        oView.getModel().refresh();
                                                    }
                                                }
                                            }
                                        );
                                    } else {
                                        MessageBox.error((result && result.error) || "Batch translation failed.");
                                    }
                                })
                                .catch(function (fetchErr) {
                                    oDialog.setBusy(false);
                                    MessageBox.error("Request error: " + fetchErr.message);
                                });

                            } catch (parseErr) {
                                oDialog.setBusy(false);
                                MessageBox.error("Failed to parse Excel file: " + parseErr.message);
                            }
                        };

                        reader.onerror = function (readErr) {
                            oDialog.setBusy(false);
                            MessageBox.error("File reading error: " + readErr.message);
                        };

                        reader.readAsArrayBuffer(oFile);
                    }
                }),
                endButton: new Button({
                    text: "Close",
                    press: function () {
                        oDialog.close();
                    }
                })
            });

            oDialog.addStyleClass("sapUiContentPadding sapUiResponsivePadding");
            oDialog.setModel(oModel, "dialog");
            oDialog.open();
        }
    });
});

